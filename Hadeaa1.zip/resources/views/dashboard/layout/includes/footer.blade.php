        <footer class="footer">
            © 2023 Dashboard <span class="d-none d-md-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i>
                by Aya Almohamad.</span>
        </footer>
